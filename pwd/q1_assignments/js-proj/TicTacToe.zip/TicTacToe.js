//This area used for global(scene) properties
//You will need to keep track of whose turn it is here..


//function that registers all event handlers for html
window.onload = function() {
    //Grab all divs using querySelectorAll
    
    //Loop through all divs and ...
    //for(... )
        //Add myClickFunction to all elements onclick attribute
}

//Implement our Click Function
function myClickFunction(ev) {
    //Determine whether we should place an X or O
    
    //change the contents of the event's target property  
    //This is the element that triggered the event by being clicked on.
    
    //Call checkWinner after we have updated the element. 
}

function checkWinner() {
    //hint: to create an empty array use:
    //   var myArray=[]; 
    
    //Check for all possible winning combinations
     // 3 possible wins across
    
    // 3 possible wins down
    
    // 2 possible wins across diagonal
    
    //If there is a winning combination, update the contents 
    //    of h1 id="winner" to say who won)
    
    //Extra Idea Goals for a challenge (not graded or required) :
    //1) try and change the style of all the divs that contain the 
    //   winning X's or O's.
    //
    // 2) Use an image (by changing its source) instead of placing text 
    //    X or text O in the div contents.  Make sure the img's css 
    //    style rules make it fit appropriately inside the div
    //
    // 3) change game to play SOS and keep track of scores for two 
    //    players
    //
    // 4) Reset game to play again after someone wins.  Alternate who
    //    starts (X or O). 
    //
    // 5) Create an algorithm that plays as the computer.
   
    
}